<?php

class egmultishopshipselfModuleFrontController extends ModuleFrontController
{

	public function initContent()
	{
		parent::initContent();

		$egmultishop = new egmultishop();
		
		$egmultishop->getMultishopDateById();
 
		$this->context->smarty->assign(array(
			'selfout' => (string)$egmultishop->getRow(0,'selfout'),
			'city_name' => (string)$egmultishop->getRow(0,'city_name')
		));	
		
		$this->setTemplate('shipself.tpl');
	}


}

?>