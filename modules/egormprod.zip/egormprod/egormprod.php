<?php
if (!defined('_PS_VERSION_'))
  exit;
  
  class egormprod extends Module
  {
	
  	const INSTALL_SQL_FILE = 'install.sql';
	const INSTALL_SQL_BD1NAME = 'egormprod';
  	
    public function __construct()
    {
	    $this->name = 'egormprod';
	    $this->tab = 'front_office_features';
	    $this->version = '0.1.1';
	    $this->author = 'Evgeny Grishin';
	    $this->need_instance = 0;
	    $this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_); 
	    $this->bootstrap = true;
	 
	    parent::__construct();
	 
	    $this->displayName = $this->l('Get content products of ormatek');
	    $this->description = $this->l('Addon for copy ormatek product information.');
	 
	    $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');
	 
  	}	
  	
  	public function getContent()
	{
		$output = null;
		
		$output.=$this->renderList();
		
		
		return $output;
	}
	
  	public function renderList()
	{
		/*			
		$fields_list = array(
			'id' => array(
				'title' => $this->l('Link ID'),
				'type' => 'text',
			),
			'shop_name' => array(
				'title' => $this->l('Shop'),
				'type' => 'text',
			),			
			'city_name' => array(
				'title' => $this->l('City'),
				'type' => 'text',
			),
			'domain' => array(
				'title' => $this->l('URL'),
				'type' => 'text',
			),	
			'processed' => array(
				'title' => $this->l('processed'),
				'type' => 'bool',
			),							
		);*/
		
		$fields_list = array(
			'id' => array(
				'title' => $this->l('Link ID'),
				'type' => 'text',
			),
			'name' => array(
				'title' => $this->l('Shop'),
				'type' => 'text',
			),			
			'date' => array(
				'title' => $this->l('City'),
				'type' => 'text',
			),
			'rating' => array(
				'title' => $this->l('URL'),
				'type' => 'text',
			),	
						
		);		
		
		$helper = new HelperList();
		$helper->shopLinkType = '';
		$helper->simple_header = true;
		$helper->identifier = 'id';
		//$helper->actions = array('edit', 'delete');
		$helper->show_toolbar = false;

		$helper->title = $this->l('Link list');
		$helper->table = $this->name;
		$helper->token = Tools::getAdminTokenLite('AdminModules');
		$helper->currentIndex = AdminController::$currentIndex.'&configure='.$this->name;
		$links = $this->getProductComments();
		if (is_array($links) && count($links))
			return $helper->generateList($links,  $fields_list);
		else
			return false;
	}		
	
	public function getProductList()
	{
		$sql = 'SELECT su.`id_shop_url` as id, su.`domain`, 
				mu.`city_name`, s.`name` as shop_name,
				0 as processed
				FROM `'._DB_PREFIX_.'shop_url` su
				INNER JOIN `'._DB_PREFIX_.'shop` s ON
					s.`id_shop`=su.`id_shop`
				LEFT JOIN `'._DB_PREFIX_.'egmultishop_url` mu ON
					mu.`id_url`=su.`id_shop_url`
				WHERE su.id_shop IN ('.implode(', ', Shop::getContextListShopID()).') ';
		
		if (!$links = Db::getInstance()->executeS($sql))
			return false;
			/*		
			foreach ($links as $link)
			{
				$http = "http://".$link['domain'];
				file_get_contents($http);
			}
			*/
		return $links;
	}
	
      public function getProductComments($url="")
    {
		header('Content-type: text/html; charset=utf-8');
		
		$url = "http://ormatek.com/products/980";
		$doc = file_get_contents($url);
	
		$doc = mb_convert_encoding($doc, 'HTML-ENTITIES', "UTF-8");
	
		$query = ".//*[@class='comment']";
	
		$dom = new DomDocument();
		libxml_use_internal_errors(true);
		$dom->loadHTML($doc);
	
		$xpath = new DomXPath($dom);
	
   		$nodes = $xpath->query($query);

	    $i = 0;
	    
	    if ($nodes->length==0)
	    	return null;
	    foreach( $nodes as $node ) 
	    {

	    	$name = $node->getElementsByTagName("b")->item(0)->nodeValue;
			$text = $node->getElementsByTagName("p")->item(0)->nodeValue;
			$date = $node->getElementsByTagName("span")->item(0)->nodeValue;
			$rating = 0;
			$rating_res = $xpath->query("div[@class='rating']/input[@checked='checked']",$node);//
		
			if($rating_res->length==0)
				continue;
			
			$rating = $rating_res->item(0)->getAttribute('value');
			
			$i++;
			
			$param[] = array(
				'id'	=> $i,
			 	'name'	=> $name,
				'date'	=> $date,
				'rating'	=> $rating,
				'text'	=> $text
			);			
	    }

	    return $param;
    }

	public function install($keep = true)
	{
		if ($keep)
			{
				if (!file_exists(dirname(__FILE__).'/'.self::INSTALL_SQL_FILE))
					return false;
				else if (!$sql = file_get_contents(dirname(__FILE__).'/'.self::INSTALL_SQL_FILE))
					return false;
				$sql = str_replace(array('PREFIX_', 'ENGINE_TYPE', 'DB1NAME'), array(_DB_PREFIX_, _MYSQL_ENGINE_, INSTALL_SQL_BD1NAME), $sql);
				$sql = preg_split("/;\s*[\r\n]+/", trim($sql));
	
				foreach ($sql as $query)
					if (!Db::getInstance()->execute(trim($query)))
						return false;
	
			}
			
	  if (!parent::install()|| 
		!Configuration::updateValue('EGORMATEKPROD_MANUF', 0)
		)
	    return false;
	  return true;
	}  	
	
  	public function reset()
	{
		if (!$this->uninstall(false))
			return false;
		if (!$this->install(false))
			return false;
		return true;
	}	
	
	public function deleteTables()
	{
		return Db::getInstance()->execute('
			DROP TABLE IF EXISTS
			`'._DB_PREFIX_.INSTALL_SQL_BD1NAME.'`');
	}	
	
	public function uninstall($keep = true)
	{
	  if (!parent::uninstall() || 
	  		!Configuration::deleteByName('EGORMATEKPROD_MANUF') ||
	  		($keep && !$this->deleteTables())
			)
	    return false;
	  return true;
	}		
	
  }
  
  